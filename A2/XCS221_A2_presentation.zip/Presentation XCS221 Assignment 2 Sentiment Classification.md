# XCS221 Assignment 2 — Sentiment Classification

**Due Sunday, September 6 at 11:59pm PT.**

---

## 1. Building Intuition for Bag-of-Words Features and Linear Classification

Social media platforms like Twitter are rich sources of emotional expression. In this homework, you’ll build classifiers to detect emotions in tweets using linear classification with cross-entropy loss and softmax activation. Consider the following dataset of 6 tweets, each labeled with exactly one emotion: joy (J), anger (A), or fear (F):

| Tweet                          | Emotion | One-hot encoding |
| ------------------------------ | ------- | ---------------- |
| “amazing day”                  | Joy     | [1, 0, 0]        |
| “scared of spiders”            | Fear    | [0, 0, 1]        |
| “love this”                    | Joy     | [1, 0, 0]        |
| “so angry”                     | Anger   | [0, 1, 0]        |
| “so so worried about tomorrow” | Fear    | [0, 0, 1]        |
| “hate waiting”                 | Anger   | [0, 1, 0]        |

Each tweet $x$ is mapped to a feature vector $f(x)$ using **bag-of-words representation** (you can think of it as word counts). Machine learning models don’t directly take a string as input; instead, as you have learned, they work with matrices (like NumPy arrays and tensors). One way to convert strings to tensors is “bag-of-words” features, which treat input texts as a “bag of words” and represents them using a vector with the same length as our vocabulary. The resulting representation is a vector, where each position corresponds to a word in the vocabulary, and each value represents how many times that word appears in the input text. If we have a very large vocabulary, we would end up with a very sparse vector with many 0’s.

For this problem, let’s assume our vocabulary consists of all unique words in the tweets above: `{about, amazing, angry, day, hate, love, of, scared, so, spiders, this, tomorrow, waiting, worried}`.

To build our multi-class classifier, we use a weight matrix $\mathbf{W} \in \mathbb{R}^{d \times 3}$ where $d$ is the feature dimension (vocabulary size) and $3$ is the number of classes. The model computes logits as $\mathbf{z} = \mathbf{W}^T f(x)$ and applies softmax to convert logits into probability values that sum to 1. Let $\mathbf{p}$ be the 3-dimensional vector of output probabilities, and $p_k$ be the probability that the $k$th element of $p$ has a true label of 1. The softmax probabilities are computed in the following way:

$$
p_k = \frac{e^{z_k}}{\sum_{j=1}^{3} e^{z_j}}
$$

Then, given the softmax probabilities, the classifier will use argmax to choose the prediction class with the highest $p_k$.

The cross-entropy loss measures the difference between a model’s predicted probabilities and the true probability distribution of the data. For a single example (with three output classes), it can be computed as follows:

$$
\mathrm{Loss}_{CE}(x, \mathbf{y}, \mathbf{W}) = -\sum_{k=1}^{3} y_k \log p_k
$$

where $\mathbf{y}$ is the one-hot encoded true label vector.

### (a) \[0.50 points (Written)] Feature Representation

Using the vocabulary given above, write out the bag-of-words feature vector $f(x)$ for the tweet “so so worried about tomorrow”.

**What we expect:** A feature vector corresponding to the vocabulary in alphabetical order: `[about, amazing, angry, day, hate, love, of, scared, so, spiders, this, tomorrow, waiting, worried]`.


$$ \phi(x)=\left[ \begin{array}{c} 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 1 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \end{array} \right] 
+
\left[ \begin{array}{c} 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 1 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \end{array} \right] 
+
\left[ \begin{array}{c} 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 1 \end{array} \right]+
\left[ \begin{array}{c} 1 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \end{array} \right]+
\left[ \begin{array}{c} 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 1 \\ 0 \\ 0 \end{array} \right]
=
\left[ \begin{array}{c} 1 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 0 \\ 2 \\ 0 \\ 0 \\ 1 \\ 0 \\ 1 \end{array} \right] \begin{array}{l} \leftarrow\text{about} \\ \leftarrow\text{amazing} \\ \leftarrow\text{angry} \\ \leftarrow\text{day} \\ \leftarrow\text{hate} \\ \leftarrow\text{love} \\ \leftarrow\text{of} \\ \leftarrow\text{scared} \\ \leftarrow\text{so} \\ \leftarrow\text{spiders} \\ \leftarrow\text{this} \\ \leftarrow\text{tomorrow} \\ \leftarrow\text{waiting} \\ \leftarrow\text{worried} \end{array}$$

![](attachment/f84736665bee0048c5ed61cb329b1712.gif)

$$ \begin{array}{l|ccccc|c} \text{sentence} & \text{i} & \text{am} & \text{happy} & \text{not} & \text{angry} & \text{sentiment} \\ \hline \text{I am happy not angry.} & 1 & 1 & 1 & 1 & 1 & \text{Joy} \\ \text{I am angry not happy.} & 1 & 1 & 1 & 1 & 1 & \text{Anger} \end{array} $$

### (b) \[1 point (Written)] Softmax Computation

Given logits $\mathbf{z} = [2.0, 1.0, -1.0]$ for the three classes \[Joy, Anger, Fear], compute the softmax probabilities. Show your work.

**What we expect:** Return the softmax probability vector $[P(\text{Joy}), P(\text{Anger}), P(\text{Fear})]$ with values rounded to 3 decimal places.

$$ \mathbf{z}=[2.0,\ 1.0,\ -1.0] \quad\text{for classes } [\text{Joy},\ \text{Anger},\ \text{Fear}] $$
![](attachment/24e75c80755a342dda45906fdad33230.gif)

**1. Compute the exponential of each logit**

$$ e^{z_i}= \begin{bmatrix} e^{2.0}\\ e^{1.0}\\ e^{-1.0} \end{bmatrix} = \begin{bmatrix} 7.389\\ 2.718\\ 0.368 \end{bmatrix} $$
```Python
import numpy as np

e_z = np.exp([2, 1, 0])
```

**2.Compute denominator used to regularise by the partition function)**


$$ \sum_j e^{z_j}=7.389+2.718+0.368=10.475 $$
**2. Compute the probabilities**
$$ \operatorname{softmax}(\mathbf{z})_i=\frac{e^{z_i}}{\sum_j e^{z_j}} $$

```Python
import numpy as np

e_z = np.exp([2, 1, 0])

softmax = e_z / np.sum (e_z)
```

$$ \operatorname{softmax}(\mathbf{z})= \begin{bmatrix} 7.389/10.475\\ 2.718/10.475\\ 0.368/10.475 \end{bmatrix} = \begin{bmatrix} 0.705\\ 0.259\\ 0.035 \end{bmatrix} \begin{matrix} \text{Joy}\\ \text{Anger}\\ \text{Fear} \end{matrix} $$

So

$$ [P(\text{Joy}),\ P(\text{Anger}),\ P(\text{Fear})]=[0.705,\ 0.259,\ 0.035] $$



### (c) \[1 point (Written)] Cross-Entropy Loss

For the tweet “so angry” with true label Anger (one-hot: `[0, 1, 0]`), suppose your model outputs probabilities `[0.2, 0.7, 0.1]`. Calculate the cross-entropy loss for this example. Then explain what happens to the loss as the predicted probability for the correct class approaches 1.

**What we expect:**

1. The numerical cross-entropy loss value

**Cross-entropy loss (CE)** measures how far the model’s predicted class probabilities are from the true labels. It is large when the model assigns low probability to the correct class and small when the predicted distribution matches the true one.

Single example:
$$
\text{CE} = -\sum_{c} y_c \log(\hat{y}_c)
$$
- $y_c$: true label for class $c$ (1 if that class is correct, 0 otherwise; one-hot) 
- $\hat{y}_c$: model’s predicted probability for class $c$ (usually softmax; values in $(0,1)$, sum to 1) 
- $c$: class index (Joy, Anger, …) 
- $\log$: natural log; the minus sign turns a high probability on the correct class into a small loss

```Python
import numpy as np

y = np.array([0, 1, 0])              # True label: anger
y_hat = np.array([0.2, 0.7, 0.1])    # predicted label: probabilities

CE = - np.sum(y * np.log(y_hat))             # sum (slow) O(n)

CE = - y @ np.log(y_hat)                     # vectorized  O(n)

CE = -     np.log(y_hat[int(np.argmax(y))])  # Smartest    O(1)
```

$$ \text{CE} = -\log(0.7) \approx 0.3567 $$

2. A brief explanation (2–3 sentences) of the loss behavior as the predicted probability for the correct class approaches 1


### (d) \[3 points (Written)] Gradient Analysis

Derive $\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k}$, the gradient of the cross-entropy loss with respect to the logit $z_k$. Show the mathematical steps to find $\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k}$ and express your final answer in terms of $p_k$ and $y_k$ only. Then, explain intuitively why this expression makes sense for gradient-based learning.

**What we expect:**

	1. Mathematical derivation showing the steps to compute $\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k}$. (Hint: you may need to use the chain rule.)
#### Cross-entropy gradient w.r.t. a logit

**Goal.** Derive $\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k}$ and write the answer using only $p_k$ and $y_k$. Then give the learning intuition.

###### Setup

Let $z \in \mathbb{R}^C$ be the logits and

$$p_c = \mathrm{softmax}(z)_c = \frac{e^{z_c}}{\sum_{j=1}^C e^{z_j}}.$$

The cross-entropy loss is

$$\mathrm{Loss}_{CE} = -\sum_{c=1}^C y_c \log p_c,$$

where $y$ is a one-hot label vector ($\sum_c y_c = 1$, $y_c \in \{0,1\}$). Labels are constants.

##### Rewrite the loss before differentiating

$$\log p_c = \log  \frac{e^{z_c}}{\sum_{j=1}^C e^{z_j}} = \log  e^{z_c} - \log \sum_j e^{z_j} = z_c - \log \sum_j e^{z_j},$$

so

$$\mathrm{Loss}_{CE} = $$

using $\sum_c y_c = 1$.

##### Differentiate

$$\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k} = $$

##### Chain rule on the log

$$\frac{\partial}{\partial z_k} \log \sum_j e^{z_j} = $$

##### Chain rule on the sum of exponentials

The inner factor is the Kronecker delta:

$$\frac{\partial z_j}{\partial z_k} = \delta_{jk} = \begin{cases} 1 & \text{if } j = k, \\ 0 & \text{otherwise.} \end{cases}$$

Every term vanishes except $j = k$, so

$$\frac{\partial}{\partial z_k} \sum_j e^{z_j} = $$

Therefore

$$\frac{\partial}{\partial z_k} \log \sum_j e^{z_j} = $$

##### Combine

2. Final gradient expression in terms of $p_k$ and $y_k$

$$\frac{\partial \mathrm{Loss}_{CE}}{\partial z_k} = p_k - y_k.$$

3. A brief intuitive explanation of why this gradient expression makes sense for learning (2–3 sentences)

###### Why this is the right signal for gradient-based learning

Gradient descent updates $z_k \leftarrow z_k - \eta (p_k - y_k)$.

- If the model is **over-confident** on class $k$ ($p_k > y_k$), the gradient is positive, so $z_k$ decreases and $p_k$ falls.
- If the model is **under-confident** on class $k$ ($p_k < y_k$), the gradient is negative, so $z_k$ increases and $p_k$ rises.
![](attachment/69231297f1023e7500251a2871fcf81e.png)
[1954 press photograph of a sample IBM punched card from the Georgetown–IBM experiment, the first public demonstration of machine translation](https://en.wikipedia.org/wiki/Georgetown%E2%80%93IBM_experiment). 

## 2. Building Intuition for Embeddings and Multilayer Perceptron

In the previous problem, we used bag-of-words features for sentiment classification. It is now an outdated method of representing texts in machine learning due to many limitations. For example, it doesn’t capture word relationships (e.g., “amazing” and “wonderful” are similar but treated as completely different features) and creates very sparse, high-dimensional vectors. In this problem, we’ll explore how neural networks with word embeddings can address these issues.

We’ll use the same set of tweets from Problem 1, but now represent each word with a dense 2-dimensional embedding vector. For simplicity, assume we have the following pre-trained word embeddings:

| Word     | Embedding    |
| -------- | ------------ |
| amazing  | [0.8, 0.6]   |
| day      | [0.2, 0.1]   |
| scared   | [-0.5, -0.7] |
| of       | [0.0, 0.0]   |
| spiders  | [-0.3, -0.4] |
| love     | [0.9, 0.4]   |
| this     | [0.0, 0.0]   |
| so       | [0.1, 0.0]   |
| angry    | [-0.6, -0.8] |
| worried  | [-0.3, -0.6] |
| about    | [0.0, -0.1]  |
| tomorrow | [0.2, -0.2]  |
| hate     | [-0.8, -0.5] |
| waiting  | [-0.1, -0.3] |

For simplicity, we will focus on **binary sentiment classification (positive or negative)** instead of three-class classification for this problem only.
![](attachment/6c605c13f50a6d20e9e645d483905975.png)
![](attachment/73df8a82a0eb1ac1c6d12a2c8365f19f.png)
### (a) \[1 point (Written)] Tweet Representation via Averaging

One simple approach is to represent each tweet as the average of its word embeddings. Compute the averaged embedding representation for “so angry”. Comment on one advantage and one disadvantage of this approach.

**What we expect:**

1. A 2-dimensional averaged embedding vector
```Python
import numpy as np

#embedding = (np.array([0.1, 0.0]) + np.array([-0.6, -0.8]))/2

embedding_so = np.array([0.1, 0.0]) 
embedding_angry = np.array([-0.6, -0.8]) 

# 1. Stack vectors into a 2D matrix of shape (2, 2) 
stacked_vectors = np.array([embedding_so, 
                            embedding_angry]) 

# 2. Reduce (average) across axis 0 
embedding = reduce(stacked_vectors, "words embed -> embed", "mean")
```
The averaged embedding representation for “so angry” is $[-0.25, -0.40]$.

2. Discuss one benefit and one limitation of creating embeddings for a text by averaging embeddings of its component words (2–3 sentences)

**Advantage: **

![](attachment/ac00628f6ccaa4734cf1e23c172fb6ef.png)

![](attachment/f3da3a2b620059f48d8400bec05c8948.png)

**Disadvantage: **

### (b) \[2 points (Written)] Forward Pass

Using the averaged representation for “so angry” from part (a), perform a forward pass step-by-step to find the predicted label $\hat{y}$. Show your intermediate calculations by filling in the table below.

For the sake of simplicity, we’ll use a 2-input, 2-hidden neuron, 1-output architecture consisting of:

1. **Input layer:** Word embeddings $\mathbf{x}$
2. **Hidden layer:** 2 neurons with ReLU activation, where $\mathrm{ReLU}(\mathbf{x}) = \max(0, \mathbf{x})$
3. **Output layer:** 1 neuron (binary sentiment classification) with sigmoid activation

The forward pass equations are:

$$
\mathbf{h} = \mathrm{ReLU}(\mathbf{W}^{(1)}\mathbf{x} + \mathbf{b}^{(1)})
$$

$$
z = \mathbf{W}^{(2)}\mathbf{h} + b^{(2)}
$$

$$
\hat{y} = \sigma(z) = \frac{1}{1 + e^{-z}}
$$

where $\mathbf{x} = [x_1, x_2]^T$ is the 2D input representation, $\hat{y}$ is the predicted label, $\mathbf{W}^{(1)} \in \mathbb{R}^{2 \times 2}$, $\mathbf{b}^{(1)} \in \mathbb{R}^{2}$, $\mathbf{W}^{(2)} \in \mathbb{R}^{1 \times 2}$, and $b^{(2)} \in \mathbb{R}$.

**Network parameters:**

$$
\mathbf{W}^{(1)} = \begin{bmatrix} 1.0 & 0.5 \\ -0.5 & 1.0 \end{bmatrix}, \quad
\mathbf{b}^{(1)} = \begin{bmatrix} 0.1 \\ -0.2 \end{bmatrix}
$$

$$
\mathbf{W}^{(2)} = \begin{bmatrix} 0.8 & -0.6 \end{bmatrix}, \quad
b^{(2)} = 0.3
$$

You should write your answers by copying and pasting the given table and filling its cells, or using bullet points to clearly state the value of each cell.

**What we expect:** Compute forward pass values at each node. Show your calculations for each step by filling in the table provided.

| Node/Variable | Formula/Computation | Value |
| --- | --- | --- |
| $\mathbf{x}$ | NA | |
| $\mathbf{h}$ | | |
| $z$ | | |
| $\hat{y}$ | | |

$$
\mathbf{h} = \mathrm{ReLU}(\mathbf{W}^{(1)}\mathbf{x} + \mathbf{b}^{(1)})
$$
```Python
import numpy as np

h = np.maximum(0,(np.array([[1.0, 0.5], [-0.5, 1.0]]) @ np.array([-0.25, -0.40]) + np.array([0.1, -0.2])))

```

$$
h = \operatorname{ReLU}\!\left(
\begin{bmatrix}
1.0 & 0.5 \\
-0.5 & 1.0
\end{bmatrix}
\begin{bmatrix}
-0.25 \\
-0.40
\end{bmatrix}
+
\begin{bmatrix}
0.1 \\
-0.2
\end{bmatrix}
\right)
$$
$$
h = \operatorname{ReLU}\!\left(
\begin{bmatrix}
1.0 * -0.25 + 0.5 * -0.40\\
-0.5 * -0.25 + 1.0 * -0.40
\end{bmatrix}
+
\begin{bmatrix}
0.1 \\
-0.2
\end{bmatrix}
\right)
$$
$$
h = \operatorname{ReLU}\!\left(
\begin{bmatrix}
-0.35 \\
-0.475 
\end{bmatrix}
\right) 
=
\begin{bmatrix}
0 \\
0
\end{bmatrix}
$$
$$z = \mathbf{W}^{(2)}\mathbf{h} + b^{(2)}
$$
$$
z = 
\begin{bmatrix}
0.8 & -0.6 \\
\end{bmatrix}
\begin{bmatrix}
0.0 \\
0.0
\end{bmatrix}
+
0.3
= 0.3
$$
$$
\hat{y} = \sigma(z) = \frac{1}{1 + e^{-z}}
$$
$$
\hat{y} = \sigma(0.3) = \frac{1}{1 + e^{-0.3}} = \frac{1}{1 + 0.7408} = 0.57444
$$
### (c) \[6 points (Written)] Backpropagation

Using the same weights, bias and input vector as in part (b), first compute the loss value $L$. Then, perform backpropagation to compute gradients $\frac{\partial L}{\partial \mathbf{W}^{(1)}}$, $\frac{\partial L}{\partial \mathbf{b}^{(1)}}$, $\frac{\partial L}{\partial \mathbf{W}^{(2)}}$, and $\frac{\partial L}{\partial b^{(2)}}$. Assume the true label is $y_{\mathrm{true}} = 0$ (negative sentiment) and we’re using binary cross-entropy loss:

$$
L = -\bigl[y_{\mathrm{true}} \log(\hat{y}) + (1 - y_{\mathrm{true}}) \log(1 - \hat{y})\bigr]
$$

You should write your answers by copying and pasting the tables below and filling their cells, or using bullet points to clearly state the value of each cell.

| Variable | Formula/Computation | Value |
| --- | --- | --- |
| $L$ | | |

| Gradient | Formula (Chain Rule) | Evaluated Value |
| --- | --- | --- |
| $\frac{\partial L}{\partial \hat{y}}$ | | |
| $\frac{\partial L}{\partial z}$ | | |
| $\frac{\partial L}{\partial \mathbf{h}}$ | | |
| $\frac{\partial L}{\partial \mathbf{W}^{(2)}}$ | | |
| $\frac{\partial L}{\partial b^{(2)}}$ | | |
| $\frac{\partial L}{\partial \mathbf{W}^{(1)}}$ | | |
| $\frac{\partial L}{\partial \mathbf{b}^{(1)}}$ | | |

**What we expect:**

1. Compute the loss value $L$
2. Starting from $\frac{\partial L}{\partial \hat{y}}$, compute gradients for each node working backwards and fill out the tables given above. For the formula column, you should express each partial in terms of partials above it in the table (recall backpropagation from lecture!)
3. Feel free to reuse values you already computed in part (b)

### COMPLETE THAT PART

### (d) \[0.50 points (Written)] Embedding Analysis

Looking at the provided word embeddings, identify patterns in how positive emotion words, negative emotion words, and neutral words are positioned in the 2D embedding space. You don’t have to plot anything for this problem; simply observe the patterns. What does this suggest about how word embeddings capture semantic relationships?

**What we expect:**

1. Describe the spatial clustering of different word types (1–2 sentences)


![](attachment/e58f736748f101c6f4264bb86bbedbaf.png)

```Python
import matplotlib.pyplot as plt

words = {
    "amazing":  [0.8, 0.6],
    "day":      [0.2, 0.1],
    "scared":   [-0.5, -0.7],
    "of":       [0.0, 0.0],
    "spiders":  [-0.3, -0.4],
    "love":     [0.9, 0.4],
    "this":     [0.0, 0.0],
    "so":       [0.1, 0.0],
    "angry":    [-0.6, -0.8],
    "worried":  [-0.3, -0.6],
    "about":    [0.0, -0.1],
    "tomorrow": [0.2, -0.2],
    "hate":     [-0.8, -0.5],
    "waiting":  [-0.1, -0.3],
}

fig, ax = plt.subplots(figsize=(10, 8))
xs = [v[0] for v in words.values()]
ys = [v[1] for v in words.values()]
ax.axhline(0, color="#ccc", lw=0.8)
ax.axvline(0, color="#ccc", lw=0.8)
ax.scatter(xs, ys, s=90, zorder=3)
for w, (x, y) in words.items():
    ax.annotate(w, (x, y), xytext=(8, 6), textcoords="offset points")
ax.set_xlabel("Dimension 1")
ax.set_ylabel("Dimension 2")
ax.set_title("2D Word Embedding Space")
ax.set_aspect("equal")
plt.show()
```

2. Explain how embeddings capture semantic similarity and its advantage over bag-of-words (1–2 sentences)

See the impact of word similarity using dot products:

* The dot product of **amazing** `[0.8, 0.6]` and **love** `[0.9, 0.4]` gives **0.96**.
* The dot product of **scared** `[-0.5, -0.7]` and **love** `[0.9, 0.4]` gives **-0.73**.
* The dot product of **so** `[0.1, 0.0]` and **love** `[0.9, 0.4]` gives **0.09**.
---

## 3. Linear Classifier

Now, we will implement the first classifier that can classify tweet sentiments. Recall that in our data, each tweet is labeled with one of three emotions (joy, anger, or fear) in one-hot encoding. For example:

| Text | One-hot label |
| --- | --- |
| i feel very happy and excited since i learned so many things | [1, 0, 0] |
| i feel angered and firey | [0, 1, 0] |
| i remember feeling acutely distressed for a few days | [0, 0, 1] |

### (a) \[2 points (Coding)] Build vocabulary

Implement `build_vocabulary(examples)`, which builds a vocabulary using words seen in the training examples. Your implementation should populate the `Vocabulary` class provided in `util.py`, which will be used in part (b) to build a sparse feature representation for any input text.

**What we expect:** Implement `build_vocabulary(examples)` using the `Vocabulary` class from `util.py`.

🛑 **Stop!** **read `util.py` first.** It defines a vocabulary class for managing word-to-index mappings in NLP tasks. This class maintains bidirectional mappings between words and their indices, with special tokens for padding (`<PAD>`) and unknown words (`<UNK>`).

> [!note]
>  **List comprehension** is a efficient way in Python to create a new list from an existing sequence in a single line of code. **List comprehension**  is **20%** quicker than an explicit `for` loop.
> ```Python 
> # Keep only even numbers 
> evens = [x**2 for x in range(10) if x % 2 == 0] 
> # Output: [0, 4, 16, 36, 64]
> ```
> 


```Python
vocab = Vocabulary()
## ### START CODE HERE ###
# examples is a list of text strings

# iterate over each string of the list examples

	# for each string, separate the words separated by space and convert
	# to a list of words
	
	
	# iterate over the list of words
	
			# Add each word to the vocabulary using the method
			# add_word(self, word: str) from the Vocabulary class.
			

return vocab
## ### START CODE HERE ###
```

**Using list comprehension**:
```Python
vocab = Vocabulary()
## ### START CODE HERE ###
# Add all words from each example text string to the vocabulary
[   ]

return vocab
## ### START CODE HERE ###
```

### (b) \[2 points (Coding)] Text to Features

Implement `text_to_features(text, vocab)`, which converts a text string into a sparse feature vector. Reference 1(a) if you want to revisit the steps for this process.

We need to convert a text into a single high-dimensional bag-of-words (or count / one-hot) feature vector over a vocabulary of size \(V\), which is a sparse feature representation.:
$$
\mathbf{x} = [0,\ 1,\ 0,\ 0,\ \ldots,\ 1,\ 0,\ 1] \in \mathbb{R}^{V}
$$
@param text: An input text string to be converted to features
@param vocab: A Vocabulary() object containing the word-to-index mapping
@return: A numpy array of shape (vocab.size(),) where each element represents the count of the corresponding vocabulary word in the input text. **Words not in vocabulary are mapped to the `<UNK>` token index, this is done automatically for you**.

```Python
features = np.zeros(vocab.size())
## ### START CODE HERE ###
# Convert the string into a list of words separated by a space
words = 

# iterate over the list of words
for word in words:
			# obtain the index number of the word using the method get_index()
			# and increase features at the position of the word
			# get_index() return 1 is the word is not part of the vocabulary
			

return features
## ### END CODE HERE ###
```

### (c) \[2 points (Coding)] NumPy Softmax

**Parameters**
- **logits**: A 2-D NumPy array of shape `(batch_size, k)`.  
  Each row holds the raw, unnormalised scores for one example across the `k` classes.

**Returns**
- A 2-D NumPy array of the same shape `(batch_size, k)`.  
  Each row is a valid probability distribution: the values are all between 0 and 1 and they sum to 1.  


🛑 **Watch out: broadcasting with a batch **

To compute **Batch** $Z\in\mathbb{R}^{B\times C}$:
$$ \operatorname{softmax}(Z)_{b,c}=\frac{e^{Z_{b,c}}}{\sum_{j=1}^{C}e^{Z_{b,j}}} \qquad b=1,\dots,B,\quad c=1,\dots,C $$
The sum is only over the class axis \(j\); the batch index \(b\) stays fixed. That is what `np.exp` + reduce along `axis=-1` (or `axis=1`) does.

Row-wise equivalent:
$$ \operatorname{softmax}(Z)_{b,:}=\frac{\exp(Z_{b,:})}{\sum_{j=1}^{C}\exp(Z_{b,j})} $$
(the denominator is a scalar per row and then broadcasts).

`np.exp(logits)` produces a 2-D array of the same shape as `logits`:
```text
exp_logits          shape (batch_size, k)
                    batch_size = batch size, k = classes
```
```

A plain sum over classes collapses that last axis:

```python
np.sum(exp_logits, axis=1)     # shape (batch_size,)
```

You divide a 2-D array of exponents by the **row sums**. Those two arrays do not have the same shape, so NumPy needs broadcasting.

You now want to divide every entry by its row sum:
```text
(batch_size, k) / (k,)  -> raises ValueError: operands could not be broadcast together
```

**Broadcasting fails**, as NumPy aligns shapes from the **right**:
```text
exp_logits:     batch_size    k
sums:                         batch_size
                              ↑ mismatch — k and batch_size are different
```

The length -\(batch_size\) vector is treated as sitting on the **class** axis, not the batch axis. Division is illegal and raises a `ValueError: operands could not be broadcast together`.

For broadcasting to work, we need the sums to have size (batch_size, 1), thus rather than using a simple np.sum:
```Python
np.sum(exp_logits, axis=1)     # shape (batch_size,)
```
We could use **reduce** from the **`einops`** library to obtain a 2D array of shape **(batch_size, 1)** , which will reduce class but leaves a dummy axis of size 1 instead of dropping it, or use **`Numpy with keepdims=True`**:
```Python
reduce(exp_logits, "batch class -> batch 1", "sum") # (B, 1)

np.sum(exp_logits, axis=1, keepdims=True) # (B, 1) 
```

|                                               | axis 0 (batch) | axis 1 (class) |
| --------------------------------------------- | -------------- | -------------- |
| `exp_logits`                                  | \(batch_size\) | \(k\)          |
| row sums (`keepdims` / reduce to `"batch 1"`) | \(batch_size\) | \(1\)          |
- Last axes: \(k\) vs \(1\) → the size-1 axis is stretched to \(k\).
- First axes: \(batch_size\) vs \(batch_size\) → already match.

So the division
```text
(batch_size, k) / (batch_size, 1)
```
is valid: each row is divided by **its own** sum. The result stays shape \((batch_size, k)\).

```Python
# reduce(tensor, "input_axes -> output_axes", "reduction")
# Here the pattern is "batch class -> batch 1":
# Left of ->: logits is treated as (batch, class).
# Right of ->: keep batch, and turn the reduced class axis into a size-1 axis.
# "max": the values along class are reduced by taking the maximum.
# So if logits is (B, K), the result is (B, 1): one max per row.
logits = logits - reduce(logits, "batch class -> batch 1", "max")
# ### START CODE HERE ###
# compute the exponent of the logits
# softmax = exp(x - max(x)) / sum(exp(x - max(x))) for each batch
# logits: 2D array of shape (batch_size, k)
exp_logits = 

#  (batch_size, k) / (batch_size, 1) -> Result shape: (batch_size, k)   
return  

# ### END CODE HERE ###
```
### (d) \[2 points (Coding)] NumPy Cross-Entropy Loss

Implement `numpy_cross_entropy_loss(predictions, targets, epsilon)`, which returns a floating point number measuring how far the predicted probabilities are from the true one-hot labels, on average.

```Python
# ### START CODE HERE ###

# Element-wise product y ⊙ log(p + ε). 
# The same name "batch_size" appears on both inputs and on the output, 
# so examples are never mixed: row n is multiplied only with row n. 
# Result stays (batch_size, k). 
# For a one-hot target, each example in the batch therefore zeros every 
# class except that example’s own true class.
CE_vector = 

# Sum over every remaining axis (all examples and all classes) to a scalar, 
# then negate. Empty right-hand side "->" means “reduce everything”. 
# Implements -∑_n ∑_k y_{nk} log(p_{nk} + ε)
return 

# ### END CODE HERE ###
```

### (e) \[2 points (Coding)] NumPy Gradient Computation

Implement `numpy_compute_gradients(features, predictions, targets)`, which returns the gradients for weight and bias, respectively. This is later used to update model weights using backpropagation.

The component-wise result
$$ \frac{\partial \mathrm{Loss}_{CE}}{\partial z_k} = p_k - y_k $$
is already the \(k\)-th entry of the full gradient. Collecting every component therefore gives the vector identity
 $$ \nabla_{\mathbf{z}}\,\mathrm{Loss}_{CE} = \mathbf{p} - \mathbf{y} $$

Equivalently, in Jacobian notation,
$$\frac{\partial\mathrm{Loss}_{CE}}{\partial\mathbf{z}}
=\mathbf{p}-\mathbf{y}.$$
We have:
$$z=XW+b$$
- $X$ is $(batch size, D)$
- $W$ is $(D, K)$
- $b$ is $(1, K)$

By the chain rule,
$$
\frac{\partial L}{\partial W}=\frac{\partial z}{\partial W}\frac{\partial L}{\partial z}=X^\top\frac{\partial L}{\partial z}\qquad
$$
$$
\frac{\partial L}{\partial b}=\frac{\partial z}{\partial b}\frac{\partial L}{\partial z}=\mathbf{1}^\top\frac{\partial L}{\partial z}.
$$

(The intermediate factors are the local Jacobians of the affine map $z=XW+b$: $\partial z/\partial W=X^\top$ and $\partial z/\partial b=\mathbf{1}^\top$.)


```Python
batch_size = features.shape[0]
# ### START CODE HERE ###
# Compute the dz derivative
# (batch_size, K) = (batch_size, K) - (batch_size, K)
dz =  # (batch_size, K)

#use einsum from the library einops
# features: (batch, features), dz: (batch, classes) → (features, classes)
grad_weights =  # shape (num_features, K)

#use reduce from the library einops
# dz: (batch, classes) → (1, classes)
grad_bias =  # shape (1, K)

return grad_weights, grad_bias
# ### END CODE HERE ###
```

### (f) \[2 points (Coding)] Linear classifier predictor

Implement `predict_linear_classifier(features, labels, weights, bias)`, which makes predictions on input features using trained weights and bias, and computes the accuracy of the predictions.

Your implementation should include:

- Compute logits by multiplying features with weights and adding bias
- Apply softmax to convert logits to probabilities
- Get predicted class labels by taking the argmax of probabilities
- Compare with true labels to compute accuracy

##### Shapes
features : (B, D)
weights  : (D, K)
bias     : (1, K)     # broadcasts over B
logits   : (B, K)
labels   : (B, K)     # one-hot
pred / y : (B,)
accuracy : scalar

```Python
# 1. Scores / logits, shape (B, K): 
# features @ weights → (B, D) @ (D, K) = (B, K) 
# then add bias; (1, K) broadcasts over the batch. 

logits =  # (B, K)

# 2. Predicted class ids, shape (B,): 
# argmax over the class axis (axis=1), not over the batch. 
# keepdims=False is easiest here.
pred = # (B,)

# 3. True class ids, shape (B,): 
# labels are one-hot, so the class id is also an argmax over axis=1. 
# Do not rebuild a one-hot matrix from the predictions.
y =  # (B,) one-hot → class id

# 4. Accuracy: # fraction of examples where predicted id == true id. # np.mean(boolean_array) gives that fraction; cast to float if needed. # The return value must be a scalar, not an array of shape (B,) or (B, K).
accuracy = 

return accuracy
```

### (g) \[5 points (Coding)] Train linear classifier

Implement `train_linear_classifier(...)` which integrates all previous components into a complete training loop.

Your implementation should:

- Initialize weights randomly and bias as a 0-vector
- For each epoch: compute forward pass, calculate loss, compute gradients, and update parameters correspondingly. At the end of the epoch, print out the training loss and validation accuracy
- Use your implemented softmax, cross-entropy loss, gradient, and predictor functions
- You should train the model on training data only; **do not train the model on validation data.**

logits     = train_features @ weights + bias          # (N, K)
probs      = numpy_softmax(logits)                    # (N, K)
loss       = numpy_cross_entropy_loss(probs, train_labels)
dW, db     = numpy_compute_gradients(train_features, probs, train_labels)
weights   -= lr * dW
bias      -= lr * db
val_acc    = predict_linear_classifier(val_features, val_labels, weights, bias)
print epoch, loss, val_acc

```Python
num_train_examples, num_features = train_features.shape
weights = np.random.randn(num_features, K)
bias = np.zeros((1, K))

# ### START CODE HERE ###

# Initialize weights randomly and bias as a 0-vector
# Already implemented with weights = np.random.randn(num_features, K)


# Iterate num_epochs of times



# --- forward pass on TRAIN data only ---

# logits: (N, D) @ (D, K) + (1, K) → (N, K)


    # row-wise softmax → class probabilities (N, K)


    # scalar training loss (mean CE over the N examples)

  
    # --- backward pass ---

    # dW has shape (D, K), db has shape (1, K) [match your helper]


    # full-batch SGD / GD step


    # --- evaluate *after* the update, on VAL data only ---

    # predictor returns a float accuracy in [0, 1]



    print(f"Epoch {epoch}: train loss = {loss:.4f}, val acc = {val_acc:.4f}")

return weights, bias

# ### END CODE HERE ###
```

Finally, run `python submission.py --model linear`. The autograder requires that you achieve at least a **0.45 accuracy** using default hyperparameters.


**If you have issues with 3f-2-hidden, check Slack:** https://xcs221.slack.com/archives/C0BQDU3ANU9/p1788375081429359?thread_ts=1787590718.768669&cid=C0BQDU3ANU9
![](attachment/02fef5a296c11b6c7d6a2826a3a6e5a4.png)


### (h) \[0.50 points (Written)] Writeup

If you adjust `lr`, the learning rate, how do you expect loss and validation accuracy to change during training? Run the terminal command `python submission.py --model linear --lr [your learning rate]` to experiment with three different learning rates. Report what they are and what training behaviors you observed. Why did the learning rate affect loss and accuracy this way?

For example, you can run: `python submission.py --model linear --lr 0.1`. If you don’t include an `--lr` argument, the default learning rate is `0.2`.

**What we expect:** In 2–3 sentences, report three different `lr`s you experimented with, and describe how they affected training behaviors. Explain why the learning rate affects loss and accuracy this way.

![](attachment/27ee3092370cb9c1569b2e217f28ea5a.png)


---

## 4. Multilayer Perceptron and Embeddings

Linear classification was a simple attempt at detecting tweet sentiments. In class, we learned that word embeddings and neural networks are powerful tools in natural language processing, and we will now implement them.

To build embeddings, we convert each word into a small, dense “embedding” vector (such as a 32-dimensional array of numbers) that captures the word’s meaning. To obtain the embedding for each text, we simply average all the word embeddings to get one fixed-size vector per document — so a 500-word document and a 10-word document both become the same size vector, making them perfect inputs for your multilayer perceptron classifier while preserving much more semantic information than word counts alone.

We will implement a simple 2-layer neural network consisting of:

- An input layer that takes averaged embeddings of size `embedding_dim`
- A hidden layer that uses ReLU activation
- An output layer that produces raw scores (logits) for each sentiment class

**Note that this is different from the architecture described in problem 2.**

### (a) \[2 points (Coding)] Text to average embedding

Implement `text_to_average_embedding(text, vocab, embedding_layer)`, which converts a text string into a single embedding vector by averaging word embeddings. This creates a fixed-size representation for variable-length tweets.

Your implementation should include:

- Create a list of indices, with each position corresponding to the vocabulary index of the words in the input text.
- Create a PyTorch tensor from the list of indices (hint: use `dtype=torch.long`).
- Pass the tensor of indices through the embedding layer to get word embeddings
- Average the embeddings across the word dimension to get a single vector (hint: use einops)
- Return the averaged embedding as a tensor

You will need to use a method `get_vector` from the class Vocabulary in `util.py`, which returns a **1D PyTorch Tensor** (`torch.Tensor`):
```Python
def get_vector(self, word: str, embedding_layer: nn.Embedding) -> torch.Tensor:
"""
Get embedding vector for a word using the embedding layer.

@param word: The word to get the embedding vector for
@param embedding_layer: PyTorch embedding layer containing word vectors
@return: The embedding vector for the word (detached from computation graph)
"""
word_idx = self.get_index(word)

return embedding_layer.weight[word_idx].detach() # Detach to avoid autograd issues
```

```Python
# Create a list of indices, with each position corresponding to the vocabulary index of the words in the input text.

# convert the string into a list word
words = 

# if words is empty return a single 
if not words:
    return 

# Use Python list comprehension to transforms a sequence of text tokens into a list of PyTorch tensors using the method vocab.get_vector.
vectors = 

# torch.stack transforms a list of 1D vectors into a 2D matrix of shape (n, dim)
word_embeddings = 

# Compute the averag embedding by using the reduce function from einops
# it is easier to understand compared to a command such as embeddings.mean(dim=0)
# as you explicitely state which dimensions remain and which one dissapears.
avg_embedding = 

# Return the averaged embedding as a tensor
return avg_embedding

```

### (b) \[2 points (Coding)] Extract averaged features

Implement `extract_averaged_features(texts, vocab, embedding_layer)`, which processes a list of text strings and converts them all into a single tensor of averaged embeddings. This function builds on your `text_to_average_embedding` implementation to handle entire datasets at once.

Your implementation should:

- Initialize an empty list to collect the embedding vectors
- Loop through each text string in the input list
- For each text, call your `text_to_average_embedding` function to get its averaged embedding
- Append each averaged embedding to your collection list
- Combine all individual embeddings into a single tensor
- Return a tensor of shape `(num_texts, embedding_dim)` where each row is one text’s embedding

**Hint:** This function essentially applies your single-text embedding function to every text in a batch, then organizes the results into the matrix format that your MLP classifier expects.

```Python
# We use list comprehension to create a list of the embedding vectors using the function text_to_average_embedding by iterating over texts
features = 

# At the end of this loop, features is a Python list containing num_texts individual 1D PyTorch tensors.
# We need to combine the Python list of 1D tensors into a single 2D matrix by stacking them along a new first dimension (dimension 0) to obtain the following shape
# use torch.stack to convert the Python list of PyTorch embeddings into a PyTorch tensor of shape (num_texts, embedding_dim)
return 
```

### (c) \[2 points (Coding)] MLP classifier

Complete the `MLPClassifier` class.

Look at [XSC221 PytTorch](https://proed.stanford.edu/mod/video/view.php?id=54463), [# CS224N: PyTorch Tutorial (Winter '21)](https://web.stanford.edu/class/archive/cs/cs224n/cs224n.1214/materials/CS224N_PyTorch_Tutorial.html) [Pytorch tutorial XCS224R 2025](https://colab.research.google.com/drive/1sYhpnlk8ynK4xSSqVmqlhQfPU8b84gHJ?usp=sharing)

```Python
# ### START CODE HERE ###
#Project to Hidden Layer: Maps the input embeddings from embedding_dim to hidden_dim using a linear transformation.
x = 

# Apply Activation: Passes the result through ReLU (max(0,x)) to introduce non-linearity so the network can learn complex patterns.
x = 

# Project to Output: Maps the hidden features from hidden_dim to output_dim to match the target classes.
x = 

#Return Logits: Returns the final raw prediction scores (logits) for each class.
return x
# ### END CODE HERE ###
```

### (d) \[2 points (Coding)] Utility functions

Implement the helper functions tailored to our three-class prediction task.

- `torch_softmax(logits)`: Convert logits to probabilities
```Python
# ### START CODE HERE ###
# https://docs.pytorch.org/docs/2.14/generated/torch.nn.Softmax.html
# need to specify dim (int) – A dimension along which Softmax will be computed (so every slice
# along dim will sum to 1).
return 
# ### END CODE HERE ###
```

- `torch_cross_entropy_loss(predictions, targets)`: A custom function that computes the average cross entropy loss of each training batch
```Python
# Computes the categorical cross-entropy loss between target probability distributions and predicted probabilities, using `epsilon` for numerical stability to prevent log(0).
return 
```

- `update_parameter(param, grad, lr)`: Manual gradient descent update
```Python
# Temporarily disable gradient tracking to update model weights without building a computational graph (`with torch.no_grad()`)
# Manually apply stochastic gradient descent (SGD) by subtracting the gradient * learning rate from the parameter
with torch.no_grad(): 
    
```

### (e) \[2 points (Coding)] MLP predictor function

Implement `predict_mlp(texts, labels, classifier, embedding_layer, vocab)`, which evaluates a trained model on new text data.

Your implementation should:

- Set models to evaluation mode (no training)
- Extract averaged embeddings for the input texts
- Pass embeddings through the classifier to get predictions
- Compare predictions with true labels to compute accuracy

```Python
# Disable gradient calculations to save memory and speed up computation during evaluation
with torch.no_grad():
    # Generate aggregated feature embeddings for the input texts using the vocabulary and embedding layer
    features = 
    # Pass the extracted features through the classifier model to get unnormalized class scores (logits)
    logits = 
    # Get the predicted class indices by finding the position of the highest logit score along each row
    predictions = 
    # Convert one-hot encoded ground truth labels into class indices
    true_labels = 
    # Calculate classification accuracy by comparing predictions to true labels and taking the average
    accuracy = 
# Return the scalar accuracy value
return accuracy
```
### (f) \[5 points (Coding)] Train MLP classifier

Implement `train_mlp_classifier(...)`.

This is the main training function that integrates everything together. Your implementation should:

- Build vocabulary from training texts
- Create and initialize embedding layer and MLP classifier
- Set up training loop with batch processing
- For each epoch: extract features, forward pass, compute loss, backpropagation, update parameters. At the start of each epoch, you should shuffle training data before processing them in batches. At the end of the epoch, print out the training loss and validation accuracy
- Use stochastic gradient descent to update all parameters; **do not use optimizers** (if you don’t know what they are, that’s perfectly fine!)
- You should train the model on training data only; **do not train the model on validation data.**

You can test your implementation with this terminal command: `python submission.py --model mlp`. The autograder requires that you achieve at least a **0.55 accuracy** using default hyperparameters.

```Python
# Create classifier network
    # Instantiate the multilayer perceptron classifier with specified input, hidden, and output dimensions
    classifier = 

    # Convert labels to tensors
    # Convert training label array/list to a 32-bit floating-point PyTorch tensor
    train_labels_tensor = 
    # Convert validation label array/list to a 32-bit floating-point PyTorch tensor
    val_labels_tensor = 

    # Collect all parameters for manual updates (no optimizer needed)
    # Combine parameters from both embedding and classifier layers into a single list for optimization
    all_parameters = 

    # Training loop
    # Iterate through the dataset for the specified number of training epochs
    
        # Set to training mode
        # Set the embedding layer to training mode (enables dropout/batchnorm updates if present)
        
        # Set the classifier to training mode
        

        # Shuffle training data
        # Generate a random permutation of indices to shuffle training samples each epoch
        indices = 
        # Initialize cumulative loss accumulator for the current epoch
        epoch_loss = 
        # Initialize counter for the number of processed batches
        num_batches = 

        # Iterate through the training dataset in minibatches of size batch_size
        
            # Select the slice of randomized indices for the current batch
            batch_indices = 

            # Get batch texts and labels
            # Retrieve text samples corresponding to the batch indices
            batch_texts = 
            # Slice the target label tensors using the batch indices
            batch_labels = 

            # Extract averaged embeddings for batch (using second script approach)
            # Compute average embedding representations for the current batch of texts
            batch_features = 

            # Forward pass through classifier
            # Zero gradients manually
            # Iterate through all trainable parameters across both models
            
                # Check if gradient tensor exists for the current parameter
                
                    # Clear accumulated gradients from previous iteration by setting them to zero
                    

            # Compute unnormalized logit predictions by passing feature embeddings through classifier
            
            # Apply custom softmax function to logits to obtain predicted class probabilities
            
            # Calculate cross-entropy loss between predicted probabilities and target labels
            

            # Backward pass
            # Compute gradients of the loss with respect to all trainable parameters via backpropagation
            

            # Manual parameter updates using SGD
            # Iterate through all parameters to update their weights manually
            
                # Ensure parameter has computed gradients before attempting an update
                
                    # Update parameter values using custom gradient descent step function
                    

            # Accumulate scalar loss value for training tracking
            
            # Increment batch counter
            

        # Calculate average training loss across all batches in the current epoch
        

        # Set embedding layer to evaluation mode (disables dropout/batchnorm updates)
        
        # Set classifier to evaluation mode
        

        # Compute validation accuracy on validation set using current model state

        # Print formatted epoch number, average training loss, and validation accuracy
        print(f"Epoch {epoch+1:3d}/{num_epochs}: Train Loss = {avg_loss:.4f}, Val Acc = {val_accuracy:.4f}")

    # Return trained classifier, embedding layer, and vocabulary mapping
    return classifier, embedding_layer, vocab
```

---

## 5. Product Ethics Exploration: Usage, Audience, and Safety

You will choose a modern AI product to analyze throughout the assignments and gain initial access to it. Please note that the questions regarding your chosen product are interconnected and will progressively build upon each other from one assignment to the next.

**Suggested resources:**

- Pick an AI-powered product or tool (not just a raw LLM chatbot) that is accessible to you. Good candidates include: Cursor, Nano Banana, ElevenLabs, Perplexity, Claude Code, etc. Free trials or student-accessible tools are recommended.
- The product’s official website and onboarding/getting started pages
- Privacy policy, Terms of Service, Acceptable Use Policy
- App store listings, GitHub documentation or READMEs (if open-source or developer-targeted)
- Recent news coverage (e.g., TechCrunch, The Verge, Wired, NYT technology section)
- Reddit communities, Hacker News, or user forums for first impressions and experiences

**In this part:** You will investigate who uses the product, how it’s intended to be used, and what safeguards exist against misuse.

**Why it’s important:** Understanding the gap between intended and actual use, as well as potential safety risks, helps identify where AI systems can cause harm despite good intentions.

**Suggested resources:**

- Company “About,” “Press,” or “Investors” pages for user numbers
- Third-party analytics sites (e.g., SimilarWeb, Statista) for user data
- Case studies or testimonials published by the company
- Safety guidelines or misuse policies
- Blog posts about misuse mitigation

### (a) \[0.50 points (Written)] Product User Base and Demographics

- Research and report any available data on the product’s users: total number of users, historical growth, and demographic breakdowns such as user type, geography, and age group. Cite your sources (e.g., company “About,” “Press,” or “Investors” pages, third-party analytics sites).

**What we expect:** Provide a 2–3 sentence summary of the product’s user numbers and user composition, with cited sources.

### (b) \[0.50 points (Written)] Intended Use Cases and Audience

- Summarize what you learn about the intended use cases for this product. Who are the primary target users? Reference product documentation, official resources, or company case studies/testimonials as appropriate.

**What we expect:** In 2–3 sentences, identify and concisely describe the main intended uses and user groups for the product.

### (c) \[0.50 points (Written)] Market Share and Competitors

- Determine the current market share of this product compared to key competitors. If exact figures are unavailable, provide best available estimates or relevant data/quotes from news or analytics sources.

**What we expect:** In 3–4 sentences, include a comparative overview of the product’s market position, citing sources or providing reasonable estimates.

### (d) \[0.50 points (Written)] Misuse Risks and Company Safeguards

- Discuss at least one way the product could be misused. What steps, if any, does the company take to safeguard against this misuse? Reference any published safety guidelines, usage policies, or blog posts about misuse mitigation.
- Consider the concept of **dual use technology**: AI systems can be used for both beneficial and harmful purposes, making governance challenging. How does your chosen product exemplify this dual-use nature? Can you identify both a beneficial use case and a potential harmful misuse of the same underlying technology?

**What we expect:** In 4–6 sentences, identify a realistic misuse scenario and summarize the company’s corresponding safety policies or interventions. Additionally, discuss how the product demonstrates dual-use characteristics, providing examples of both beneficial and potentially harmful applications.

### (e) \[0.50 points (Written)] Gaps and Unintended Use Cases

- Are there any aspects of user information or misuse that appear not to be safeguarded against—based on what you can find published by the company or in trusted third-party reports? Briefly discuss.
- Provide at least one example of an unintended use case of the product—something the company likely did not intend, but that users or communities have pursued anyway. Cite examples if you find them.

**What we expect:** In 2–3 sentences, briefly discuss gaps in company safeguards and highlight at least one notable unintended use case, with references to sources.

---


> [!Speed with list comprehension]
> To demonstrate the efficiency of **list comprehension**, we have provided code showing that creating a list with a list comprehension is **1.2x faster** than using a traditional `for` loop.
> 
> It also shows that being smart and **precomputing** values in the example below is **1.3x faster**.

```Python
import random
import time

# List - Approach 1 : Iterative [slow]
def function_inefficient_list(n):
    result = []
    for i in range(n):
        result.append(i)
    return result

# List - Approach 2 : List Comprehension [Quick as using C libraries]
def function_list_comprehension(n):
    return [i for i in range(n)]

# contains squares using all the numbers in x [Quick as efficient and keeping tab of previous]
def dict_with_precomputing(numbers_list):
    even_dict = {}
    for list_item in numbers_list:
        if (list_item % 2) == 0 and list_item not in even_dict:
            even_dict[list_item] = list_item**2
    return even_dict

# Slow, as brute force approach may recompute the same value multiple times
def dict_without_precomputing(numbers_list):
    return {i: i**2 for i in numbers_list if i % 2 == 0}

if __name__ == "__main__":
    n = 10_000_000

    # -------------------------------------------------------------
    # 1. Compare List Creation: Iterative vs List Comprehension
    # -------------------------------------------------------------
    start = time.perf_counter()
    function_inefficient_list(n)
    time_loop = time.perf_counter() - start

    start = time.perf_counter()
    function_list_comprehension(n)
    time_comp = time.perf_counter() - start

    speedup_list = time_loop / time_comp

    print("--- List Creation Speed ---")
    print(f"Iterative loop time:      {time_loop:.4f} seconds")
    print(f"List comprehension time: {time_comp:.4f} seconds")
    print(f"--> List comprehension is ~x{speedup_list:.1f} quicker than using a for loop.\n")
    print()

    # -------------------------------------------------------------
    # 2. Compare Dictionary Creation: Precomputing vs Brute Force
    # -------------------------------------------------------------
    data_for_dict = [random.randint(-10, 10) for _ in range(n)]

    start = time.perf_counter()
    dict_without_precomputing(data_for_dict)
    time_no_precomp = time.perf_counter() - start

    start = time.perf_counter()
    dict_with_precomputing(data_for_dict)
    time_precomp = time.perf_counter() - start

    speedup_dict = time_no_precomp / time_precomp

    print("--- Dictionary Precomputing Speed ---")
    print(f"Brute force dict time:   {time_no_precomp:.4f} seconds")
    print(f"Precomputing dict time:  {time_precomp:.4f} seconds")
    print(f"--> Precomputing is ~x{speedup_dict:.1f} quicker than the brute force approach.")
```